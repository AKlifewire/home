// Minimal stub for getDevices Lambda handler
exports.getDevices = async (event) => {
  return {
    success: true,
    devices: [],
    message: 'Stub getDevices handler: no devices found.'
  };
};
