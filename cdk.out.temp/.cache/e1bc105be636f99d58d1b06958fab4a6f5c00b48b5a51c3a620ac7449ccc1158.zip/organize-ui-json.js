const AWS = require('aws-sdk');
const s3 = new AWS.S3();

/**
 * Organizes UI JSON files in the correct folder structure during deployment:
 * 
 * - /auth/login.json
 * - /auth/signup.json
 * - /auth/forgot_password.json
 * - /roles/owner/dashboard.json
 * - /roles/tenant/dashboard.json
 * - /roles/admin/dashboard.json
 * - /devices/esp32/control.json
 * - /devices/generic/home.json
 */
exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  const sourceBucket = process.env.SOURCE_BUCKET;
  const destinationBucket = process.env.UI_BUCKET;
  
  if (!sourceBucket || !destinationBucket) {
    throw new Error('SOURCE_BUCKET and UI_BUCKET environment variables must be set');
  }
  
  try {
    // List all JSON files in the source bucket
    const sourceFiles = await s3.listObjectsV2({
      Bucket: sourceBucket,
      Prefix: 'ui-json/'
    }).promise();
    
    // Define the file organization rules
    const rules = [
      { test: /\/(login|signup|forgot_password)\.json$/, folder: 'auth' },
      { test: /\/owner\/.*\.json$/, folder: 'roles/owner' },
      { test: /\/tenant\/.*\.json$/, folder: 'roles/tenant' },
      { test: /\/admin\/.*\.json$/, folder: 'roles/admin' },
      { test: /\/esp32\.json$/, folder: 'devices/esp32' },
      { test: /\/(home|dashboard)\.json$/, folder: 'devices/generic' }
    ];
    
    // Process each file
    for (const file of sourceFiles.Contents) {
      const filename = file.Key.split('/').pop();
      
      // Find the matching rule
      const rule = rules.find(r => r.test.test(file.Key));
      if (!rule) continue;
      
      // Get the source file
      const sourceData = await s3.getObject({
        Bucket: sourceBucket,
        Key: file.Key
      }).promise();
      
      // Upload to the new location
      const destinationKey = `${rule.folder}/${filename}`;
      await s3.putObject({
        Bucket: destinationBucket,
        Key: destinationKey,
        Body: sourceData.Body,
        ContentType: 'application/json'
      }).promise();
      
      console.log(`Organized ${file.Key} -> ${destinationKey}`);
    }
    
    return {
      statusCode: 200,
      body: 'UI JSON files organized successfully'
    };
  } catch (error) {
    console.error('Error organizing UI JSON files:', error);
    throw error;
  }
};
