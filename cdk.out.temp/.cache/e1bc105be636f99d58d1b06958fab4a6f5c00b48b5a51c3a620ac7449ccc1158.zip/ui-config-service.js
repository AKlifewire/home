/**
 * UI Configuration Service
 * 
 * This service handles the generation, storage, and retrieval of UI JSON configurations
 * for the backend-driven UI system. It supports:
 * 
 * 1. Dynamic UI generation based on user roles and device types
 * 2. Storage of UI configurations in S3
 * 3. Versioning and caching of UI configurations
 * 4. Role-based UI customization
 */

const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const dynamodb = new AWS.DynamoDB.DocumentClient();

// UI Configuration Service
class UiConfigService {
  constructor(options = {}) {
    this.cacheEnabled = options.cacheEnabled ?? true;
    this.cacheExpiration = options.cacheExpiration ?? 300; // 5 minutes
    this.cache = {};
    // Read config from environment variables
    this.uiBucket = process.env.UI_BUCKET;
    this.usersTable = process.env.USERS_TABLE;
    
    // Debug logging
    if (!this.uiBucket) {
      console.error('UI_BUCKET environment variable is not set!');
    } else {
      console.log('Using UI_BUCKET:', this.uiBucket);
    }
    if (!this.usersTable) {
      console.warn('USERS_TABLE environment variable is not set. Role-based UI may not work.');
    } else {
      console.log('Using USERS_TABLE:', this.usersTable);
    }
  }

  /**
   * Get UI configuration for a specific user, device type, and UI component
   */
  async getUiConfig(params) {
    const { userId, deviceType = 'generic', uiType = 'dashboard', version = 'latest' } = params;

    // Handle auth UI directly
    if (uiType === 'login' || uiType === 'signup' || uiType === 'forgot_password') {
      console.log(`Directly fetching ${uiType}.json from auth folder`);
      try {
        const uiJson = await this.getUiFromS3(`auth/${uiType}.json`);
        return { 
          success: true,
          data: JSON.stringify(uiJson),
          message: null
        };
      } catch (error) {
        console.error(`Error loading ${uiType} UI:`, error);
        return {
          success: false,
          data: null,
          message: error.message || `Failed to load ${uiType} UI`
        };
      }
    }

    // Get user role from userId
    let userRole = 'default';
    if (userId) {
      try {
        userRole = await this.getUserRole(userId);
      } catch (error) {
        console.warn('Failed to get user role:', error);
      }
    }

    // Generate cache key
    const cacheKey = `${userRole}:${deviceType}:${uiType}:${version}`;

    // Check cache first if enabled
    if (this.cacheEnabled && this.cache[cacheKey] &&
      (Date.now() - this.cache[cacheKey].timestamp) < (this.cacheExpiration * 1000)) {
      console.log(`Cache hit for ${cacheKey}`);
      return {
        success: true,
        data: JSON.stringify(this.cache[cacheKey].data),
        message: null
      };
    }

    // Try to get role-specific UI first
    try {
      // For role-specific pages like dashboard, use roles/[role] folder
      if (uiType === 'dashboard' || uiType.startsWith('page/')) {
        const roleSpecificKey = `roles/${userRole}/${uiType}.json`;
        console.log(`Trying to get role-specific UI: ${roleSpecificKey}`);
        const uiConfig = await this.getUiFromS3(roleSpecificKey);
        
        // Store in cache
        if (this.cacheEnabled) {
          this.cache[cacheKey] = {
            data: uiConfig,
            timestamp: Date.now()
          };
        }
        
        return {
          success: true,
          data: JSON.stringify(uiConfig),
          message: null
        };
      }
      
      // For device-specific UIs like 'esp32', check device type folder
      const deviceTypeKey = `devices/${deviceType}/${uiType}.json`;
      console.log(`Trying to get device-type UI: ${deviceTypeKey}`);
      const uiConfig = await this.getUiFromS3(deviceTypeKey);
    } catch (error) {
      console.log(`Role-specific UI not found: ${error.message}`);
      
      // Fall back to device-type specific UI
      try {
        const deviceTypeKey = `${deviceType}.json`;
        console.log(`Trying to get device-type UI: ${deviceTypeKey}`);
        const uiConfig = await this.getUiFromS3(deviceTypeKey);
        
        // Store in cache
        if (this.cacheEnabled) {
          this.cache[cacheKey] = {
            data: uiConfig,
            timestamp: Date.now()
          };
        }
        
        return {
          success: true,
          data: JSON.stringify(uiConfig),
          message: null
        };
      } catch (error) {
        console.log(`Device-type UI not found: ${error.message}`);
        return {
          success: false,
          data: null,
          message: 'UI configuration not found'
        };
      }
    }
  }

  /**
   * Get UI configuration from S3
   */
  async getUiFromS3(key) {
    const bucket = this.uiBucket;
    if (!bucket) throw new Error('UI_BUCKET environment variable is not set');
    console.log(`Getting UI file from S3: ${bucket}/${key}`);
    try {
      const data = await s3.getObject({
        Bucket: bucket,
        Key: key
      }).promise();
      return JSON.parse(data.Body.toString());
    } catch (error) {
      console.error(`Error getting ${key} from S3:`, error);
      throw error;
    }
  }

  /**
   * Store UI configuration in S3
   */
  async storeUiConfig(params) {
    const { uiType, deviceType = 'generic', uiConfig, version = 'latest' } = params;

    try {
      const bucket = this.uiBucket;
      if (!bucket) throw new Error('UI_BUCKET environment variable is not set');
      
      await s3.putObject({
        Bucket: bucket,
        Key: `${deviceType}/${uiType}-${version}.json`,
        Body: JSON.stringify(uiConfig),
        ContentType: 'application/json'
      }).promise();

      // Invalidate cache for this UI type
      if (this.cacheEnabled) {
        Object.keys(this.cache).forEach(key => {
          if (key.includes(uiType)) {
            delete this.cache[key];
          }
        });
      }

      return {
        success: true,
        data: JSON.stringify(uiConfig),
        message: 'UI configuration stored successfully'
      };
    } catch (error) {
      console.error('Error storing UI config:', error);
      return {
        success: false,
        data: null,
        message: error.message || 'Failed to store UI configuration'
      };
    }
  }

  /**
   * Get user role from userId 
   */
  async getUserRole(userId) {
    if (!this.usersTable) {
      console.warn('USERS_TABLE environment variable is not set. Returning default role.');
      return 'default';
    }
    try {
      const params = {
        TableName: this.usersTable,
        Key: { id: userId }
      };
      const result = await dynamodb.get(params).promise();
      return result.Item?.role || 'default';
    } catch (error) {
      console.error('Error getting user role:', error);
      return 'default';
    }
  }

  /** 
   * Clear the UI configuration cache
   */
  clearCache() {
    this.cache = {};
  }
}

module.exports = UiConfigService;

/**
 * Load backend config from SSM
 */
async function loadBackendConfig() {
  const ssm = new AWS.SSM();
  const params = {
    Names: [
      "/myapp/dev/UI_BUCKET",
      "/myapp/dev/USERS_TABLE",
      "/myapp/dev/COGNITO_USER_POOL_ID",
      "/myapp/dev/COGNITO_CLIENT_ID",
      "/myapp/dev/APPSYNC_API_URL"
    ],
    WithDecryption: true
  };

  try {
    const data = await ssm.getParameters(params).promise();
    data.Parameters.forEach(param => {
      process.env[param.Name.split('/').pop()] = param.Value;
      console.log(`Loaded ${param.Name} from SSM`);
    });
  } catch (error) {
    console.error("Error loading backend config from SSM:", error);
  }
}

// Load backend config on startup
loadBackendConfig();