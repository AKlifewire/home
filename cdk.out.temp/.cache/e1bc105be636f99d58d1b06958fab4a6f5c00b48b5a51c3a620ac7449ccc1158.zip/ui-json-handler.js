const UiConfigService = require('./ui-config-service');
const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient();
const s3 = new AWS.S3();

const DEVICE_TABLE = process.env.DEVICES_TABLE;
const UI_BUCKET = process.env.UI_BUCKET;

/**
 * Lambda function to retrieve UI JSON configurations from S3
 */
exports.getUiJson = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  try {
    // Initialize UI Config Service
    const uiConfigService = new UiConfigService({
      uiBucket: process.env.UI_BUCKET
    });
    
    // Extract parameters from the event
    const userId = event.arguments?.userId;
    const deviceType = event.arguments?.deviceType || 'generic';
    const uiType = event.arguments?.uiType || 'dashboard';
    
    // Get UI configuration
    const uiConfig = await uiConfigService.getUiConfig({
      userId,
      deviceType,
      uiType
    });
    
    return {
      success: true,
      data: JSON.stringify(uiConfig),
      message: 'UI JSON retrieved successfully'
    };
  } catch (error) {
    console.error('Error retrieving UI JSON:', error);
    
    // Try to get a fallback generic UI
    try {
      const fallbackKey = 'home.json';
      
      console.log(`Trying fallback UI JSON from S3: ${fallbackKey}`);
      
      const fallbackData = await s3.getObject({
        Bucket: process.env.UI_BUCKET,
        Key: fallbackKey
      }).promise();
      
      const fallbackJson = JSON.parse(fallbackData.Body.toString('utf-8'));
      
      return {
        success: true,
        data: JSON.stringify(fallbackJson),
        message: 'Fallback UI JSON retrieved successfully'
      };
    } catch (fallbackError) {
      return {
        success: false,
        data: null,
        message: `Error retrieving UI JSON: ${error.message}`
      };
    }
  }
};

/**
 * Lambda function to generate and store UI JSON configurations
 */
exports.generateUiJson = async (event) => {
  console.log('Generate UI Event:', JSON.stringify(event, null, 2));
  
  try {
    // event: { deviceId: string }
    const { deviceId } = event;
    if (!deviceId) return { statusCode: 400, body: 'Missing deviceId' };

    // 1. Fetch device metadata
    const device = await ddb.get({
      TableName: DEVICE_TABLE,
      Key: { deviceId }
    }).promise().then(res => res.Item);

    if (!device) return { statusCode: 404, body: 'Device not found' };

    // 2. Generate UI layout based on components
    const uiLayout = {
      type: 'column',
      children: [
        { type: 'text', text: `Device: ${device.deviceId}` },
        ...(device.components || []).map(comp => {
          if (comp.type === 'relay') {
            return {
              type: 'button',
              label: comp.label || comp.id,
              action: { componentId: comp.id, type: 'toggle' }
            };
          }
          if (comp.type === 'temperature') {
            return {
              type: 'text',
              text: `${comp.label || comp.id}: {temperature}`,
              style: { fontSize: 18 }
            };
          }
          // Add more component types as needed
          return { type: 'text', text: `${comp.label || comp.id} (unknown)` };
        })
      ]
    };

    // 3. Store in S3
    await s3.putObject({
      Bucket: UI_BUCKET,
      Key: `ui-json/${deviceId}.json`,
      Body: JSON.stringify(uiLayout),
      ContentType: 'application/json'
    }).promise();

    return { statusCode: 200, body: 'UI JSON generated' };
  } catch (error) {
    console.error('Error generating UI JSON:', error);
    
    return {
      success: false,
      data: null,
      message: `Error generating UI JSON: ${error.message}`
    };
  }
};

/**
 * Lambda function to clear the UI configuration cache
 */
exports.clearUiCache = async (event) => {
  console.log('Clear Cache Event:', JSON.stringify(event, null, 2));
  
  try {
    // Initialize UI Config Service
    const uiConfigService = new UiConfigService({
      uiBucket: process.env.UI_BUCKET
    });
    
    // Clear the cache
    const result = uiConfigService.clearCache();
    
    return {
      success: true,
      message: 'UI configuration cache cleared successfully'
    };
  } catch (error) {
    console.error('Error clearing UI cache:', error);
    
    return {
      success: false,
      message: `Error clearing UI cache: ${error.message}`
    };
  }
};