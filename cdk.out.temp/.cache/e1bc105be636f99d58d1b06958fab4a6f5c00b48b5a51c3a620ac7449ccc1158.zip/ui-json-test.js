/**
 * Test script for UI JSON configuration service
 * 
 * This script tests the UI configuration service by:
 * 1. Loading UI JSON configurations from S3
 * 2. Generating dynamic UI configurations
 * 3. Testing role-based UI customization
 * 4. Verifying cache functionality
 */

const AWS = require('aws-sdk');
const UiConfigService = require('./ui-config-service');

// Configure AWS SDK
const region = process.env.AWS_REGION || 'us-east-1';
AWS.config.update({ region });

// Initialize services
const s3 = new AWS.S3();
const dynamodb = new AWS.DynamoDB.DocumentClient();

// Test configuration
const testConfig = {
  uiBucket: process.env.UI_BUCKET || 'smart-home-ui-json-dev-12345678',
  devicesTable: process.env.DEVICES_TABLE || 'SmartHomeDevices',
  testUserId: 'test-user-123',
  testAdminId: 'admin-user-123',
  testDeviceId: 'test-device-001',
  testDeviceType: 'esp32',
};

/**
 * Main test function
 */
async function runTests() {
  console.log('Starting UI JSON configuration service tests...');
  
  try {
    // Initialize UI Config Service
    const uiConfigService = new UiConfigService({
      uiBucket: testConfig.uiBucket,
      cacheEnabled: true,
      cacheExpiration: 60 // 1 minute
    });
    
    // Test 1: Get UI configuration for a regular user
    console.log('\nTest 1: Get UI configuration for a regular user');
    const regularUserConfig = await uiConfigService.getUiConfig({
      userId: testConfig.testUserId,
      deviceType: 'generic',
      uiType: 'dashboard'
    });
    console.log('Regular user UI config title:', regularUserConfig.title);
    
    // Test 2: Get UI configuration for an admin user
    console.log('\nTest 2: Get UI configuration for an admin user');
    const adminUserConfig = await uiConfigService.getUiConfig({
      userId: testConfig.testAdminId,
      deviceType: 'generic',
      uiType: 'dashboard'
    });
    console.log('Admin user UI config title:', adminUserConfig.title);
    
    // Test 3: Generate dynamic UI for a device
    console.log('\nTest 3: Generate dynamic UI for a device');
    const deviceCapabilities = ['relay', 'temperature', 'humidity'];
    const dynamicUi = await uiConfigService.generateDynamicUi({
      deviceId: testConfig.testDeviceId,
      deviceType: testConfig.testDeviceType,
      capabilities: deviceCapabilities
    });
    console.log('Generated UI sections:', dynamicUi.sections.map(s => s.id).join(', '));
    
    // Test 4: Store UI configuration in S3
    console.log('\nTest 4: Store UI configuration in S3');
    const storeResult = await uiConfigService.storeUiConfig({
      key: `devices/${testConfig.testDeviceId}.json`,
      uiConfig: dynamicUi
    });
    console.log('Store result:', storeResult);
    
    // Test 5: Verify cache functionality
    console.log('\nTest 5: Verify cache functionality');
    console.time('First request');
    await uiConfigService.getUiConfig({
      userId: testConfig.testUserId,
      deviceType: 'generic',
      uiType: 'dashboard'
    });
    console.timeEnd('First request');
    
    console.time('Cached request');
    await uiConfigService.getUiConfig({
      userId: testConfig.testUserId,
      deviceType: 'generic',
      uiType: 'dashboard'
    });
    console.timeEnd('Cached request');
    
    // Test 6: Clear cache
    console.log('\nTest 6: Clear cache');
    uiConfigService.clearCache();
    console.log('Cache cleared');
    
    console.time('After cache clear');
    await uiConfigService.getUiConfig({
      userId: testConfig.testUserId,
      deviceType: 'generic',
      uiType: 'dashboard'
    });
    console.timeEnd('After cache clear');
    
    console.log('\nAll tests completed successfully!');
  } catch (error) {
    console.error('Test failed:', error);
  }
}

// Run the tests
if (require.main === module) {
  runTests().catch(err => {
    console.error('Error running tests:', err);
    process.exit(1);
  });
}

module.exports = { runTests };