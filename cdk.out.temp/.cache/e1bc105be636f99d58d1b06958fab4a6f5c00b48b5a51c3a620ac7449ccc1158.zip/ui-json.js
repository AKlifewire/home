const AWS = require('aws-sdk');
const s3 = new AWS.S3();

/**
 * Lambda function to retrieve UI JSON configurations from S3
 * based on user role, device type, and UI component type
 */
exports.getUiJson = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  try {
    // Extract parameters from the event
    const userId = event.arguments?.userId;
    const deviceType = event.arguments?.deviceType || 'generic';
    const uiType = event.arguments?.uiType || 'device-cards';
    
    // Get user role from Cognito or DynamoDB (simplified for now)
    const userRole = await getUserRole(userId);
    
    // Determine the S3 key based on parameters
    const s3Key = determineS3Key(userRole, deviceType, uiType);
    
    console.log(`Fetching UI JSON from S3: ${s3Key}`);
    
    // Get the JSON file from S3
    const data = await s3.getObject({
      Bucket: process.env.UI_BUCKET,
      Key: s3Key
    }).promise();
    
    // Parse the JSON content
    const uiJson = JSON.parse(data.Body.toString('utf-8'));
    
    return {
      success: true,
      data: JSON.stringify(uiJson),
      message: 'UI JSON retrieved successfully'
    };
  } catch (error) {
    console.error('Error retrieving UI JSON:', error);
    
    return {
      success: false,
      data: null,
      message: `Error retrieving UI JSON: ${error.message}`
    };
  }
};

/**
 * Determine the user's role based on userId
 * In a real implementation, this would query Cognito or DynamoDB
 */
async function getUserRole(userId) {
  if (!userId) return 'guest';
  
  // This is a simplified implementation
  // In a real app, you would query a user database or Cognito
  if (userId.includes('admin')) {
    return 'admin';
  } else if (userId.includes('owner')) {
    return 'owner';
  } else {
    return 'tenant';
  }
}

/**
 * Determine the S3 key for the UI JSON file based on parameters
 */
function determineS3Key(userRole, deviceType, uiType) {
  // Default path for generic components
  let key = `ui/json/${uiType}/generic.json`;
  
  // Try to get a more specific file based on device type
  if (deviceType && deviceType !== 'generic') {
    key = `ui/json/${uiType}/${deviceType}.json`;
  }
  
  // Check if there's a role-specific override
  const roleSpecificKey = `ui/json/${userRole}/${uiType}/${deviceType}.json`;
  
  // For now, we'll just return the standard path
  // In a real implementation, you might check if the role-specific file exists first
  return key;
}