// lambda/validate_backend_config.js
const AWS = require('aws-sdk');

const requiredVars = [
  'UI_BUCKET',
  'USERS_TABLE',
  'COGNITO_USER_POOL_ID',
  'COGNITO_CLIENT_ID',
  'APPSYNC_API_URL'
];

let missing = false;
for (const v of requiredVars) {
  if (!process.env[v]) {
    console.error(`Missing required env var: ${v}`);
    missing = true;
  }
}
if (missing) process.exit(1);

const s3 = new AWS.S3({ region: process.env.AWS_REGION || 'us-east-1' });
const dynamodb = new AWS.DynamoDB({ region: process.env.AWS_REGION || 'us-east-1' });

(async () => {
  try {
    await s3.headBucket({ Bucket: process.env.UI_BUCKET }).promise();
    console.log('S3 bucket exists:', process.env.UI_BUCKET);
  } catch (e) {
    console.error('S3 bucket does not exist or is not accessible:', process.env.UI_BUCKET);
    process.exit(1);
  }
  try {
    await dynamodb.describeTable({ TableName: process.env.USERS_TABLE }).promise();
    console.log('DynamoDB table exists:', process.env.USERS_TABLE);
  } catch (e) {
    console.error('DynamoDB table does not exist or is not accessible:', process.env.USERS_TABLE);
    process.exit(1);
  }
  // Optionally, add more checks for Cognito/AppSync if needed
})();
